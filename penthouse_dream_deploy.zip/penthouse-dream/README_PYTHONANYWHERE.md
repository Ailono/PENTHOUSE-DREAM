# Deploy on PythonAnywhere

## 1. Upload
- Create account on pythonanywhere.com
- Open Files tab
- Upload this zip
- Open Bash console and run:
  ```
  unzip penthouse_dream_deploy.zip
  cd penthouse-dream
  ```

## 2. Virtualenv
```
python -m venv venv
source venv/bin/activate
pip install -r backend/requirements.txt
```

## 3. Token
```
echo 'BOT_TOKEN=your_token_here' > .env
echo 'DB_TYPE=sqlite' >> .env
```

## 4. Run
```
python run_bot.py
```

## 5. Always-on task
Go to Tasks tab -> Always-on task -> Add:
```
source /home/YOUR_USER/penthouse-dream/venv/bin/activate && python /home/YOUR_USER/penthouse-dream/run_bot.py
```
