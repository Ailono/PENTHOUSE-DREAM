import sys
import os

BASE = os.path.dirname(os.path.abspath(__file__))
BACKEND = os.path.join(BASE, "backend")
os.chdir(BACKEND)
sys.path.insert(0, BACKEND)

import asyncio
from bot.main import main
asyncio.run(main())
